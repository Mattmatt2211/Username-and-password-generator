# -*- coding: utf-8 -*-
"""
Created on Thu Sep  8 11:45:56 2022

@author: User
"""

#import
from datetime import date #import date
import  getpass           #import username

from employee import Employee



####################################################
# Name: Matthew Dean
# Date: 09/01/2022
# Program Description:
# 
# This program is used to generate a username
# Using their first name last name, date of birth 
#
####################################################
 

#Variable
first_name = ("") # variable  for first name
last_name = ("") #variable  for last name
year_born = ("") #variable for year born

correct = ("") #input varibale for correct yes or no
dup_found = False
enter_data_tuple = [] #variable to enter data into tuple
employee_data = ()
user_list = []  #variable that will print list of generated usernames

user_s_list = []  #variable for employee dictionary

employee_greeting_age = ()
greeting = ""
age = 0
employee_data_dictionary = {} #

YES_LIST = ["yes","YES","Y","yes","y"] #yes list for validating if you entered the correct data

#new var
password = ""
password_length = ""
use_spec_chars = False
use_number = False
use_nums =""
use_spec_char =""
dup_found = False
greeting = ""
employee_greeting_age_list = []

#function session
def build_username(first,last,year,dup):
    if not dup:
        username = first[0].lower()+last.lower()+year[-2:]
    else:
        username = first.lower()+last[0].lower()+year[-2:]
        
    return username
        

#Input session

while len(enter_data_tuple) < 5: #condition that states after 5 names beak
    first_name=str(input("Enter first name:")) #input for the first unsername
    while len(first_name) < 2 : #conddition to where data must be more than two characters
        first_name=str(input("Enter your first name:")) #for if you do not follw the condition it will ask again
   
    last_name = input ("Enter your last name:") #input for the last name
    while len (last_name) <2: #condition for last name greater than two characters
        last_name = input ("Enter your Last name:") #if fial to meet condition it will ask again

    year_born = input ("Enter a year you were born:") #input for year born
    while len (year_born) < 4: #condition that year born must be lest that 4 
        year_born = input ("Enter a year you were born:") #if fail to meet those conditions ask again
        
        
        
    while True:
        password_length = input ("Enter a number between 10 and 16")
        try:
            password_length_int = int(password_length)
            if password_length_int in range(10,17):
                break
            else:
                continue
        except:
            continue 
            
    spec_char_answer = input ("do you want special characters in your password: YES or NO")
    if spec_char_answer in YES_LIST:
        use_spec_chars = True
        
    number_answer = input ("Do you want numbers in your password? YES or NO")
    if number_answer in YES_LIST:
        use_number = True
    
    print("You entered" + first_name + " " + last_name + " " + year_born + "password_Length" + str(password_length_int) + "with special characters" + spec_char_answer + "with numbers" + number_answer + "Is this correct")
    is_correct = input ("YES or NO ")
    
     
    

        
        
    print(f"Did you enter {first_name} {last_name} and year born as {year_born} is this correct?") #statement asking if name is corret
    is_correct = input ("YES or NO:")
    
    if is_correct in YES_LIST: #loop for the yes lsit
        employee_data =(first_name,last_name,year_born,password_length_int,use_spec_chars,use_number) 
        enter_data_tuple.append(employee_data)
        first_name=("")
        last_name=("")
        year_born=("")
        password_Length = ""
        password_length_int = 0
        use_nums = ""
        use_number = False
        use_spec_chars = False
        use_spec_char = ""
    else:
        first_name =("")
        last_name=("")
        year_born=("")
        password_Length = ""
        password_length_int = 0
        use_number = False
        use_spec_chars = False
        use_spec_char = ""
        use_nums = ""
        continue
        

#Process
for employee in enter_data_tuple: #loop for the employee tuple to generate username
    firs = employee[0] ##variable for first employee name
    las = employee[1] #variable for employee last name
    birth = employee[2] #variable for employee birth date
            
   # first_in = firs[0].lower() #indexes first letter in first name and lowercase
  #  last_in = las.lower() #indexes first character in last name and lowercase
   # birth_two = birth[-2:] #indexes last two characters in birthdate
    
    username = build_username(firs, las, birth, dup=False)
    
    user_list.append(username) #to append user list
    employee_data_dictionary[username] = employee #create a dictionary data structure for username    
    
    if username in user_list:
        #username = firs.lower() + last_in[0:1].lower() + birth_two
        dup_found = True
        username = build_username(firs, las, birth, dup=True)
       # user_list.append(username)
   # else:
    user_list.append(username)
    my_employee = Employee(employee[0], employee[1], employee[2], employee[3], employee[4], employee[5])
    password = my_employee.build_password()
        
    temp_tuple = (my_employee.greet_person(), my_employee.age())
    employee_greeting_age_list.append(temp_tuple)
    employee_record = [firs, las, birth, username, password]
        
    employee_data_dictionary[username] = employee_record
        
        
    
user_s_list=list(user_list)       
user_s_list.sort()
    

#Output session

print(date.today()) #prints todays date
print(getpass.getuser()) #prints usernam

for employee_greeting_age in employee_greeting_age_list:
    greeting = employee_greeting_age[0]
    age = employee_greeting_age[1]
    print(greeting + "you are" + str(age))
    
print(enter_data_tuple) #prints the employee tuple with names and birthdate
print(user_list) # prints the list of generated usernames
print(user_s_list) #prints list that was organized in order
print(employee_data_dictionary)   
    
    
    
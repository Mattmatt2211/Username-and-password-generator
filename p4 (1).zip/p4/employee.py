# -*- coding: utf-8 -*-
"""
Created on Fri Sep 16 17:30:46 2022

@author: User
"""
#import




####################################################
# Name: Matthew Dean
# Date: 09/01/2022
# Program Description:
# 
# This program is used to generate a username
# Using their first name last name, date of birth 
#
####################################################





"A set of classes used to represent employee"
from person import Person
import random

class Employee(Person):
    """ Models aspect of a person specific to an employee """
    
    def __init__(self, first_name, last_name, year_born, password_length, use_spec_chars, use_number):
        super().__init__(first_name,last_name, year_born)
        self.password_length = password_length
        self.use_spec_chars = use_spec_chars
        self.use_number = use_number
        
        
    def build_password(self):
        ALPHABET = "AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuVvWwXxYyZz"
        SPECIAL_CHARACTER = "!@#$%^&*"
        NUMBERS = "0123456789"
        
        count= 0
        password = ""
        
        while count < self.password_length:
            random_number = random.randrange(0,51,1)
            pwChar = ALPHABET[random_number]
            password = password + pwChar
            pwChar = ""
            count - count + 1
            
            if self.use_spec_chars and count < self.password_length:
                random_number = random.randrange(0,7,1)
                pwChar = SPECIAL_CHARACTER[random_number]
                password = password + pwChar
                pwChar = ""
                count = count + 1
            
            
            if self.use_number and count < self.password_length:
                random_number  = random.randrange(0,9,1)
                pwChar = NUMBERS[random_number]
                password = password + pwChar
                pwChar = ""
                count = count + 1
                return password

    
            
            
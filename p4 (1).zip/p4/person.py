# -*- coding: utf-8 -*-
"""
Created on Fri Sep 16 18:45:21 2022

@author: User
"""
#import
import datetime #import date
          #import username




####################################################
# Name: Matthew Dean
# Date: 09/01/2022
# Program Description:
# 
# This program is used to generate a username
# Using their first name last name, date of birth 
#
####################################################

class Person:
         """MODELS ASPECTS OF A PERSON"""
        
         def __init__(self,first_name, last_name, year_born):
             self.first_name = first_name
             self.last_name =last_name
             self.year_born = year_born
        
         def greet_person(self):
            greeting = f"welcome,{self.first_name}."
            return greeting
        
         def age(self):
             today = datetime.date.today()
             age = today.year - int(self.year_born)
             
             return age